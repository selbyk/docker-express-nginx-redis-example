[Contribution Guide on the wiki](https://github.com/CenturyLinkLabs/panamax-ui/wiki/Contributing-to-Panamax)
